import signinBg from './images/signin.jpg';
import signupBg from './images/signup.jpg';

const assets = {
    images: {
        signinBg: signinBg,
        signupBg: signupBg,
    }
}

export default assets;